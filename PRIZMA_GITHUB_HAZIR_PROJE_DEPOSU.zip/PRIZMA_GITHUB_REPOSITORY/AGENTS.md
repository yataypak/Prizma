# AGENTS.md — PRİZMA Yapay Zekâ Ajanı Kuralları

Bu dosya, depoda çalışan tüm yapay zekâ kodlama ajanları ve otomasyonlar için bağlayıcı proje talimatıdır.

## 1. İlk iş: depoyu tanı
- Önce `README.md`, bu dosya, `docs/`, `prompts/` ve `project/ROADMAP.md` dosyalarını oku.
- Depodaki gerçek dosyaları incelemeden var olmayan kod, servis, ekran veya entegrasyon varmış gibi davranma.
- Başlangıç raporunda mevcut durum, eksikler, çelişkiler ve varsayımları ayrı başlıklarla yaz.
- Kullanıcı istemedikçe kapsamı daraltma veya ürün adını/ana gezinmeyi değiştirme.

## 2. Ürün gerçekleri
- Ürün adı PRİZMA; sloganı “Tek Mesaj, Sonsuz Dünya”.
- Ana gezinme: Sohbetler, Kapsül, Meydan, Profil/Ayarlar.
- Platform hedefleri Android, iOS, Web ve masaüstüdür.
- Topluluklar bir veya daha fazla modülü etkinleştirebilir.
- Resmî kurum/kuruluş doğrulaması, sıradan topluluk oluşturma izninden ayrıdır.
- Kişisel ve kurumsal profiller aynı hesap altyapısını paylaşabilir.
- Modülün menüde görünmesi, işlevinin tamamlandığı anlamına gelmez.

## 3. Değişiklik güvenliği
- Çalışmaya başlamadan önce mevcut dosya yapısını ve git durumunu incele.
- Kullanıcının mevcut içeriğini izinsiz silme veya toplu yeniden yazma.
- Önce küçük ve bağımsız değişiklikler yap.
- Birden fazla modülü etkileyen değişiklikleri gerekçelendir.
- Gizli anahtar, parola, token veya gerçek kullanıcı verisini repoya ekleme.
- `.env` dosyalarını commit etme; yalnızca `.env.example` gibi sahte değerli örnekler ekle.
- Veritabanı değişikliklerini migration ile yap; geriye dönük etkileri açıkla.
- API değişikliklerini dokümante et ve sürüm uyumluluğunu değerlendir.

## 4. Kalite kuralları
- Her buton ve form gerçek bir işleme bağlı olmalı.
- Mock/demo verisini açıkça işaretle; üretim özelliği gibi gösterme.
- Loading, empty, error, success, offline ve permission-denied durumlarını ele al.
- Yetkilendirmeyi yalnızca istemcide değil, backend'de de uygula.
- Kullanıcı girdilerini doğrula; rate limit, audit log ve güvenli dosya yükleme uygula.
- Uçtan uca şifreleme için kendi algoritmanı yazma; denetlenmiş standart protokol kullan.
- Testleri çalıştırmadan “tamamlandı” deme.
- Çalıştırılamayan testleri ve nedenini açıkça raporla.

## 5. Güvenlik ve hukuk
- Telefon/e-posta gibi kişisel bilgiler varsayılan olarak gizli olmalı.
- Konum yalnızca açık izinle kullanılmalı.
- Ödeme kartı bilgilerini uygulama sunucusunda saklama; uygun ödeme sağlayıcısı kullan.
- Film, müzik, kitap ve canlı yayın içeriklerinde lisans gereksinimlerini dikkate al.
- Ekran görüntüsünü her platformda mutlak engelleyebileceğini iddia etme.
- Resmî rozet, doğrulama ve yetki incelemesi olmadan verilmemeli.
- Hassas verileri loglara yazma.

## 6. Çalışma yöntemi
Her görev için şu sırayı izle:
1. İstenen değişikliği kendi cümlelerinle tanımla.
2. İlgili mevcut dosyaları bul.
3. Etkilenecek dosyaları ve riskleri listele.
4. En küçük uygulanabilir planı sun.
5. Değişikliği uygula.
6. İlgili testleri/lint/build kontrollerini çalıştır.
7. Değişen dosyaları, sonuçları, eksikleri ve sonraki adımı raporla.

## 7. Tamamlanma ölçütü
Bir iş ancak:
- İstenen davranış uygulanmışsa,
- Yetki ve hata durumları ele alınmışsa,
- İlgili testler geçmişse veya çalıştırılamama nedeni açıklanmışsa,
- Dokümantasyon güncellenmişse,
- Mevcut işlevler bozulmamışsa
tamamlandı sayılır.

## 8. Büyük özellikler
Mesajlaşma, medya, arama, canlı yayın, oyun, ödeme ve şifreleme gibi alanları tek dosyada veya tek devasa değişiklikte geliştirme. Sınırları belirle, arayüzleri tanımla ve aşamalı uygula.

## 9. Rapor formatı
Her görev sonunda:
- Özet
- Değiştirilen/eklenen dosyalar
- Teknik kararlar
- Testler ve sonuçları
- Bilinen sınırlamalar
- Sonraki önerilen görev
başlıklarını kullan.
