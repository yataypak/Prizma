---
name: Özellik önerisi
about: PRİZMA için yeni özellik veya modül öner
title: "[FEATURE] "
labels: enhancement
---

## İhtiyaç / problem

## Önerilen çözüm

## Etkilenen modül ve ekranlar

## API / veri modeli etkisi

## Güvenlik ve gizlilik etkisi

## Kabul kriterleri
- [ ]
