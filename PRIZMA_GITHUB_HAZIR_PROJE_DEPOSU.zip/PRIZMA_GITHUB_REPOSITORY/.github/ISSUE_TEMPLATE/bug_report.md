---
name: Hata bildirimi
about: Bir hata veya beklenmeyen davranış bildir
title: "[BUG] "
labels: bug
---

## Hata özeti

## Tekrarlama adımları

## Beklenen davranış

## Gerçekleşen davranış

## Ortam / cihaz / sürüm

## Ekran görüntüsü veya log (gizli veri içermemeli)
