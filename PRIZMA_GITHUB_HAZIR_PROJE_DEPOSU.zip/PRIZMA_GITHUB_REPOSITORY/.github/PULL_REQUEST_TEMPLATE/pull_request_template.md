## Özet

## İlgili issue

## Değişen dosyalar ve modüller

## Teknik kararlar

## Testler
- [ ] Testler çalıştırıldı
- [ ] Build/lint kontrol edildi
- [ ] Yetki ve hata durumları değerlendirildi
- [ ] Dokümantasyon güncellendi

## Güvenlik / gizlilik etkisi

## Bilinen sınırlamalar
