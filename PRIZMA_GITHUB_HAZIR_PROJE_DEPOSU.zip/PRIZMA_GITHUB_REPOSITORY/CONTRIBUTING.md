# Katkı Rehberi

## Başlamadan önce
- `README.md` ve `AGENTS.md` dosyalarını okuyun.
- Değişiklikten önce mevcut davranışı ve ilgili dokümanları inceleyin.
- Büyük geliştirmeleri küçük issue ve pull request'lere bölün.

## Issue açarken
Şunları belirtin:
- Problem / ihtiyaç
- Beklenen davranış
- Etkilenen kullanıcı ve modül
- Ekran/API/veri modeli etkisi
- Güvenlik ve gizlilik etkisi
- Kabul kriterleri

## Pull request
- Tek PR'da mümkün olduğunca tek konu.
- UI değişikliği varsa ekran görüntüsü veya tasarım referansı ekleyin.
- API/veri modeli değişiyorsa dokümanı ve migration'ı güncelleyin.
- Test komutlarını ve sonuçlarını yazın.
- Mock veri veya geçici çözüm varsa açıkça belirtin.

## Doküman düzeni
- Ürün gereksinimleri `docs/` altında.
- Yapay zekâ talimatları `prompts/` altında.
- Yol haritası ve proje durumu `project/` altında.
- Görsel referanslar `assets/design-references/` altında tutulur.
- Karar değişikliklerini `CHANGELOG.md` içine ekleyin.
