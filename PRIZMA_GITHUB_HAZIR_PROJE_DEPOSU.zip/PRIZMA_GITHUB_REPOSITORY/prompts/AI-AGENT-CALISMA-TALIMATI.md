GOOGLE AI STUDIO / GEMINI İÇİN ÇALIŞMA TALİMATI

Bu projeyi üretirken aşağıdaki çalışma protokolüne uy:

1. Önce ZIP içindeki bütün .txt dokümanlarını ve görsel referansı incele.
2. Dokümanları kaynak gereksinim olarak kabul et; görseldeki bozuk/temsili metinleri birebir kopyalama.
3. Belirsiz noktaları varsayım olarak işaretle. Güvenlik, ödeme, yayın, şifreleme ve mevzuat konularında tahmin yürütme.
4. Önce mimari, teknoloji seçimi, dosya ağacı, ERD, API ve ekran planını hazırla.
5. Kullanıcı onayı ve teknik plan netleşmeden çok büyük kod çıktısı üretme.
6. Projeyi küçük, doğrulanabilir dikey dilimlerle geliştir.
7. Her özellikte frontend, backend, veritabanı, yetki, hata durumları ve testleri birlikte ele al.
8. Sadece demo gerekiyorsa demo olduğunu açıkça belirt. Demo kodunu üretim sistemi gibi sunma.
9. Her butonun gerçek bir aksiyonu olmalı. Çalışmayan veya yalnızca dekoratif buton bırakma.
10. Güvenlik kritik alanlarda standart ve denetlenmiş kütüphaneler kullan.
11. Her aşama sonunda:
   - Değişen dosyalar
   - Çalıştırma komutları
   - Migration bilgisi
   - Test sonuçları
   - Eksik kalanlar
   - Sonraki adımlar
   raporla.
12. Kodun tamamını tek yanıt içine sıkıştırma. Dosyaları proje yapısında üret ve tutarlı biçimde sürdür.
13. Mobil uygulama, web ve admin panelinin aynı API ve yetki modelini kullanmasını sağla.
14. Gerçek harici entegrasyon gerektiren alanlar için adapter ve yapılandırma noktaları oluştur; sahte entegrasyonla tamamlandı deme.

İLK KOMUT:
"Dokümanları analiz et ve PRİZMA için teknik tasarım paketini oluştur. Henüz uygulama kodu yazma. Eksik kararları, riskleri, önerilen teknoloji yığınını, klasör yapısını, veri modelini, API envanterini ve aşamalı geliştirme planını hazırla. Özellikle uçtan uca şifreleme, canlı yayın, ödeme, oyun doğrulama, resmî kurum doğrulaması ve mağaza yayın gereksinimlerini ayrı ayrı açıkla."
