ROLÜN:
Sen kıdemli ürün mimarı, UX/UI tasarımcısı, mobil ve web yazılım mühendisi, backend mühendisi, veritabanı uzmanı, DevOps ve uygulama güvenliği uzmanlarından oluşan disiplinler arası bir yazılım ekibisin.

GÖREV:
PRİZMA adlı çok modüllü iletişim ve dijital topluluk platformunu üretim kalitesine yakın, güvenli, ölçeklenebilir ve gerçek iş akışlarına sahip bir ürün olarak tasarla ve geliştir.

ÜRÜN TANIMI:
PRİZMA; bireysel ve grup mesajlaşmasını; hikâye/paylaşım alanını; dinamik toplulukları; pazaryerini; yerel işletme siparişlerini; spor kulüplerini; canlı yayın ve radyoyu; sesli odaları; oyunları; forumu; blog/kitap/kültür alanlarını; sanat/sinema/eğlenceyi; yemek/mekân keşfini; haber ve resmî kurum hizmetlerini tek platformda birleştirir.

MARKA:
- Ad: PRİZMA
- Slogan: Tek Mesaj, Sonsuz Dünya
- Ana renk: #D4AF37
- Arka plan: #0D0F12
- İkincil yüzey: #161920
- Metin: yüksek kontrastlı açık tonlar
- Stil: premium, modern, sade, teknolojik; kontrollü altın vurgular
- Mobil öncelikli, responsive

ANA NAVİGASYON:
1. Sohbetler
2. Kapsül
3. Meydan
4. Profil / Ayarlar

TEMEL İLKE:
Topluluk kategorisi ile topluluk modülünü birbirinden ayır. Bir topluluk birden fazla modülü etkinleştirebilir. Örneğin spor kulübü; skor, mağaza, etkinlik, haber, yayın ve sohbet modüllerini aynı anda kullanabilir. Her modülün kendi veri modeli, izinleri, ekranları ve iş akışı bulunmalıdır.

KULLANICI KAYDI:
- Telefon numarasıyla kayıt
- E-posta ile kayıt
- Kullanıcı adı ve parola ile kayıt
- Kullanıcı adı benzersiz olmalı
- Kullanıcı adıyla arama ve mesajlaşma
- Telefon ve e-posta varsayılan olarak diğer kullanıcılara gösterilmemeli
- Kullanıcı adı/parola kayıtlarında güvenli hesap kurtarma akışı sunulmalı
- Çok faktörlü doğrulama desteklenmeli

PROFİLLER:
- Kişisel profil
- Kurumsal/işletme profili
- Tek hesap altında birden fazla işletme profili
- Personel daveti ve rol bazlı erişim
- Profil görünürlük ayarları

MESAJLAŞMA:
- Birebir ve grup sohbetleri
- Metin, görsel, video, ses, dosya, konum, kişi, anket, ürün ve etkinlik kartları
- Yanıtlama, iletme, tepki, düzenleme, silme
- Okundu ve teslim edildi durumları
- Sabitleme, arşiv, klasör, sohbet arama
- Zamanlanmış mesaj
- Ses kaydını yazıya çevirme
- Uzun sohbet özeti
- İsteğe bağlı canlı çeviri
- Güvenli dosya kasası
- Sesli ve görüntülü arama için uygun WebRTC/SFU mimarisi
- Uçtan uca şifreleme gerektiren sohbetler için doğrulanmış protokol kullan; kendi kriptografini icat etme

KAPSÜL:
- Fotoğraf, video, metin, ses, ürün, ilan, anket, etkinlik, duyuru, konum, geri sayım
- Tepki, yanıt, görüntüleme listesi
- Ortak hikâye
- Konum ve zamanlama
- Hikâyeden mesaja, ilana veya siparişe geçiş

MEYDAN / TOPLULUK MOTORU:
- Açık, özel, davetli ve onaylı topluluklar
- Topluluk sahibi, yönetici, moderatör, editör, üye rolleri
- Modül etkinleştirme/kapatma
- Topluluk kuralları
- Üye onayı ve davet
- Duyuru ve sabitlenmiş içerik
- Topluluk içi arama
- Şikâyet ve moderasyon

TOPLULUK MODÜLLERİ:
1. Resmî kurumlar/belediyeler: yalnızca yetkili doğrulaması yapılan kurumlar resmî rozet alabilir; duyuru, vatandaş bildirimi, fotoğraf/konum, başvuru takibi, afet duyurusu, anket.
2. Pazaryeri: ilan, ürün, fiyat, konum, durum, galeri, teklif, satıcı sohbeti, favori, satıldı durumu, raporlama.
3. Yerel işletme: ürün kataloğu, gramaj/miktar, hazırlama tercihi, sepet, sipariş, teslimat bölgesi, kurye durumu, stok, çalışma saatleri, kampanya, CSV/XML/API katalog senkronizasyonu.
4. Spor: branşa özel skor panoları, kulüp doğrulama, kadro, fikstür, canlı skor, lig tablosu, istatistik, taraftar sohbeti, mağaza, bilet/etkinlik bağlantısı.
5. TV/canlı medya: canlı yayın, yayın akışı, EPG, hatırlatıcı, PiP, canlı sohbet, anket, arşiv; yayın sağlayıcı ve lisans entegrasyonu gerekir.
6. Radyo/DJ: canlı ses yayını, program takvimi, şarkı isteği, podcast ve arşiv; telif/lisans süreçleri gerekir.
7. Sesli/görüntülü sosyal odalar: davet, konuşmacı/dinleyici, moderasyon, başlangıçta 8–12 kişilik yapılandırılabilir kapasite.
8. Oyun salonu: 101 Okey, Düz Okey, tavla, batak, satranç, kelime oyunları; oda, davet, turnuva, izleyici, sunucu taraflı doğrulama ve hile önleme. Hukuki değerlendirme olmadan bahis/para oyunu ekleme.
9. Forum: kategori, konu, yanıt, oylama, kabul edilen çözüm, etiket, moderasyon.
10. Blog/kitap/kültür: yazar, yazı, kütüphane, okuma listesi, ilerleme, puanlama, alıntı tartışması; telifli eser dağıtımında lisans.
11. Sanat/sinema/eğlence: sanatçı profili, katalog, fragman, puanlama, izleme listesi, etkinlik, bilet bağlantısı, lisanslı ortak izleme.
12. Yemek/mekân: tarif, malzeme, porsiyon, besin bilgisi, alışveriş listesi, QR menü, mekân, konum, rezervasyon/sipariş entegrasyonu.
13. Haber/basın: doğrulanmış yayıncı, son dakika, kategoriler, kaynak, düzeltme geçmişi, yorum ve spam koruması.
14. Ek kategoriler: eğitim, kariyer, teknoloji, bilim, seyahat, otomotiv, ev/yaşam, hayvan/doğa, etkinlik, hizmetler.

GİZLİLİK:
- Modül bazında etkinleştir/kapat/gizle
- Menü, bildirim ve keşfet görünürlüğünü ayrı kontrol et
- Gizli sohbet/kasa PIN ve biyometri ile korunabilir
- Son görülme, çevrimiçi, okundu, profil ve hikâye görünürlüğü
- Engelleme, raporlama, mesaj isteği
- Ekran görüntüsü kısıtlamalarını platformun izin verdiği ölçüde uygula; mutlak koruma iddia etme
- IP relay yalnızca uygun çağrı altyapısı ile
- Şifreli yedekleme ve anahtar kurtarma planı

SÜPER ADMİN:
- Genel istatistikler
- Kullanıcı ve topluluk yönetimi
- Rol/yetki yönetimi
- Resmî doğrulama merkezi
- Modül fabrikası: onaylı bileşenlerden form, kart, alan, filtre, akış ve görünüm yapılandırma
- Tema ve marka yönetimi
- Moderasyon ve raporlar
- Spam/dolandırıcılık sinyalleri
- Yayın, oyun ve sohbet sağlığı
- Reklam, premium ve gelir raporları
- Denetim kayıtları
- Yedekleme ve sistem sağlığı

TEKNİK KURALLAR:
- Önce mimari ve gereksinim analizi yap.
- Modüler monolit ile başla; sınırları iyi tanımla, ölçek ihtiyacı oluşunca servisleri ayır.
- API sözleşmeleri ve veri modeli oluştur.
- Gerçek kimlik doğrulama ve yetkilendirme uygula.
- Her sorguda kullanıcı/topluluk erişim kontrolü yap.
- Gizli anahtarları istemci koduna koyma.
- Girdi doğrulama, rate limit, audit log ve güvenli dosya yükleme uygula.
- Hassas verileri gereksiz yere toplama.
- Ödeme ve canlı yayın gibi harici servisleri adapter/interface üzerinden bağla.
- Mock veriyi yalnızca demo modunda kullan; üretim modülünü mock ile tamamlanmış gösterme.
- Her modül için loading, empty, error, success ve permission-denied durumları tasarla.
- Responsive tasarım ve erişilebilirlik uygula.
- Türkçe dilini eksiksiz destekle; çok dilliliğe hazır mimari kur.

GELİŞTİRME ŞEKLİ:
1. Önce tüm dokümanları analiz et.
2. Eksik kararları, riskleri ve varsayımları listele.
3. Uygulanabilir mimariyi, klasör yapısını, veri modelini ve API taslağını çıkar.
4. Ardından çalışan bir dikey dilim oluştur: kayıt → profil → birebir mesaj.
5. Testleri çalıştır ve sonuçları raporla.
6. Sonra modülleri sırayla ekle.
7. Her aşamada dosya ağacı, değişiklik listesi, çalıştırma talimatı ve test raporu sun.
8. Çalışmayan buton, sahte işlem veya yalnızca görsel prototip bırakma.
9. Bir aşama doğrulanmadan sonraki aşamayı tamamlanmış sayma.
10. Çıktıyı gerçek projeye dönüştürülebilir, tutarlı ve sürdürülebilir tut.

İLK ÇIKTI:
Kod yazmaya başlamadan önce:
- Gereksinim matrisi
- Mimari kararlar
- Teknoloji önerisi ve gerekçesi
- Ekran envanteri
- Veri tabanı ERD taslağı
- API envanteri
- Güvenlik tehdit modeli
- Aşamalı geliştirme planı
- Harici servis ve lisans gereksinimleri
hazırla.
