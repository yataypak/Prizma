# Her yeni yapay zekâ ajanı için ilk görev

Bu depoyu çektiğinde önce `AGENTS.md` ve `README.md` dosyalarını oku.

İlk turda kod veya dokümanları değiştirme. Şunları raporla:
1. Depodaki mevcut dosya ve modüllerin özeti.
2. Ürün gereksinimlerinde çelişki veya eksik kalan kararlar.
3. Güvenlik, ölçek, maliyet, telif ve mevzuat riskleri.
4. Önerilen teknoloji yığını ve gerekçesi.
5. İlk çalışan dikey dilim için dosya planı ve test planı.
6. Kullanıcıdan netleştirilmesi gereken sorular.

Varsayımları gerçek karar gibi sunma. Çalışmayan özelliği tamamlanmış gösterme.
