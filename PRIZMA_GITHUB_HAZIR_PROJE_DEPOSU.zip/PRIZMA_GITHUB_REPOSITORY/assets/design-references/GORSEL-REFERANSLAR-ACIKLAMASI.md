PRİZMA – GÖRSEL REFERANS AÇIKLAMASI

Bu paketteki PRIZMA_Ana_Tanitim_ve_Ekran_Konseptleri.png dosyası, PRİZMA'nın görsel yönünü anlatan konsept panosudur.

Görselde temsil edilen ana alanlar:
- Marka logosu ve açılış ekranı
- Sohbet listesi
- Kapsül hikâye akışı
- Meydan topluluk keşfi
- Kişisel profil
- Pazaryeri
- Canlı yayın
- Oyun salonu
- Forum
- Haber akışı

Görsel, gerçek uygulamanın çalışan ekran görüntüsü değildir. Görseldeki bazı metinler yapay görsel üretiminde temsili olabilir. Nihai arayüz metinleri bu dokümanlardaki ekran şartnamesine göre uygulama bileşenleriyle oluşturulmalıdır.

TASARIM HEDEFİ:
- Siyah/antrasit zemin
- Metalik altın marka vurgusu
- Kategoriye göre kontrollü renkler
- Modern kartlar
- Tutarlı ikonlar
- Okunabilir metin
- Gerçek cihaz boyutlarında responsive tasarım
