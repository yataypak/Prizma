PRİZMA – GELİŞTİRME YOL HARİTASI

AŞAMA 0 – ANALİZ VE TASARIM
Teslimler:
- Gereksinim matrisi
- Mimari karar kaydı
- Ekran haritası
- Tasarım sistemi
- ERD ve API sözleşmesi
- Risk ve lisans listesi

AŞAMA 1 – ÇALIŞAN TEMEL
- Kayıt/giriş
- Profil
- Kullanıcı arama
- Birebir sohbet
- Gerçek zamanlı mesaj
- Dosya ve bildirim
- Temel admin

AŞAMA 2 – TOPLULUK VE KAPSÜL
- Hikâyeler
- Topluluk oluşturma
- Üyelik ve roller
- Modül yapılandırma
- Keşfet
- Topluluk sohbeti ve duyuru

AŞAMA 3 – TİCARET VE RESMÎ KURUMLAR
- Pazaryeri
- İşletme profili
- Katalog ve stok
- Sepet/sipariş
- Kurum doğrulama
- Vatandaş başvuruları

AŞAMA 4 – SPOR, YAYIN VE SOSYAL
- Spor kulübü
- Skor ve fikstür
- Canlı yayın entegrasyonu
- Radyo
- Sesli/görüntülü odalar

AŞAMA 5 – OYUN VE İÇERİK
- Oyun odaları
- Forum
- Blog/kitap
- Sinema/sanat
- Yemek/mekân
- Haber/basın

AŞAMA 6 – GELİR VE İLERİ YÖNETİM
- Premium
- Reklam
- İşletme planları
- Modül fabrikası
- Gelişmiş moderasyon
- Analitik

AŞAMA 7 – ÜRETİM HAZIRLIĞI
- Yük ve güvenlik testleri
- Performans
- Yedekleme/geri yükleme
- İzleme
- Mağaza uyumluluğu
- Yayın ve operasyon dokümantasyonu

HER AŞAMA TESLİMİ:
- Kaynak kod
- Güncel dosya ağacı
- Kurulum ve çalıştırma talimatı
- Ortam değişkeni örneği
- Veritabanı migration'ları
- Test raporu
- Bilinen sorunlar
- Sonraki aşama planı
