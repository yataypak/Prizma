# Mimari Karar Kaydı

Bu dosyaya proje boyunca alınan ve ürünün yönünü etkileyen kararlar eklenir.

## ADR-0001: Modüler ürün yaklaşımı
- Durum: Önerildi
- Karar: Ortak kimlik, kullanıcı, yetki ve topluluk çekirdeği üzerinde modüler ürün alanları.
- Gerekçe: Topluluk türleri farklı özellikler kullanırken ortak altyapıdan yararlanmalı.

## ADR-0002: Başlangıç mimarisi
- Durum: Önerildi
- Karar: Modüler monolit ile başla; servis sınırlarını koru. Ölçek ve ekip ihtiyacı doğduğunda servisleri ayır.
- Gerekçe: Erken aşamada dağıtık sistem operasyon yükünü azaltmak.

## ADR-0003: Resmî kurum doğrulaması
- Durum: Ürün gereksinimi
- Karar: Herkes topluluk oluşturabilir; resmî kurum kimliği ve rozeti yalnızca doğrulama süreciyle verilir.
- Gerekçe: Sahte resmî hesap riskini azaltmak.

Yeni kararlar ADR-0004 ve devamı olarak eklenmelidir. Karar; bağlam, seçenekler, sonuç ve durum içermelidir.
