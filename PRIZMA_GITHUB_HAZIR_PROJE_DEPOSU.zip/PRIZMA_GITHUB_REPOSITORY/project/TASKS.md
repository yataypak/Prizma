# İlk Geliştirme Görevleri

## Ön analiz
- [ ] Tüm gereksinimleri tutarlılık açısından incele
- [ ] Açık ürün kararlarını ve varsayımları çıkar
- [ ] Teknoloji yığınını gerekçeli öner
- [ ] ERD ve API taslağını gözden geçir
- [ ] Tehdit modeli oluştur

## İlk çalışan dikey dilim
- [ ] Proje iskeleti ve ortam yapılandırması
- [ ] Kayıt/giriş ve güvenli oturum
- [ ] Profil oluşturma ve düzenleme
- [ ] Kullanıcı arama
- [ ] Birebir sohbet oluşturma
- [ ] Gerçek zamanlı mesaj gönderme/alma
- [ ] Mesaj geçmişi ve yetkilendirme
- [ ] Temel testler ve CI

## Sonraki ürün alanları
- [ ] Kapsül
- [ ] Topluluk motoru ve roller
- [ ] Pazaryeri
- [ ] Yerel işletme siparişleri
- [ ] Resmî kurum doğrulama
- [ ] Spor
- [ ] Canlı yayın/radyo/sesli odalar
- [ ] Oyun
- [ ] Forum ve yayıncılık
- [ ] Süper Admin
