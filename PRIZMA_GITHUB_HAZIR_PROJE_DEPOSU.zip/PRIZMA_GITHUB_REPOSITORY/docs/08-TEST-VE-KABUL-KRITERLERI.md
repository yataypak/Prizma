PRİZMA – TEST VE KABUL KRİTERLERİ

GENEL KURAL:
Bir ekranın açılması veya butonun görünmesi, özelliğin tamamlandığı anlamına gelmez. İşlem backend'e kaydedilmeli, yetki kontrolünden geçmeli ve hata durumları doğru ele alınmalıdır.

AUTH:
- Telefon/e-posta/kullanıcı adı kayıt akışları doğrulanır.
- Kullanıcı adı benzersizliği test edilir.
- Yanlış parola ve rate limit test edilir.
- Oturum kapatma ve cihazdan çıkış çalışır.
- Hesap kurtarma kötüye kullanım testinden geçer.

MESSAGING:
- İki kullanıcı gerçek zamanlı mesajlaşır.
- Teslim ve okundu durumu tutarlı olur.
- Yetkisiz kullanıcı sohbeti okuyamaz.
- Dosya türü ve boyut sınırları uygulanır.
- Engellenen kullanıcı mesaj gönderemez.
- Zamanlanmış mesaj doğru zamanda gönderilir.

COMMUNITY:
- Açık topluluğa katılım çalışır.
- Özel toplulukta onay/davet gerekir.
- Rol izinleri backend tarafında doğrulanır.
- Modül etkinleştirme topluluk bazında saklanır.
- Topluluk dışı kullanıcı özel içeriği göremez.

MARKETPLACE:
- İlan oluşturma, düzenleme, kapatma çalışır.
- Teklif ve karşı teklif geçmişi tutulur.
- Satıldı durumu güncellenir.
- İlan raporlama çalışır.

COMMERCE:
- Stok ve miktar doğrulanır.
- Sepet toplamı sunucuda yeniden hesaplanır.
- Sipariş durum geçişleri kural bazlıdır.
- Kullanıcı yalnızca kendi siparişini görür.
- İptal/iade politikası uygulanır.

OFFICIAL:
- Doğrulanmamış hesap resmî rozet alamaz.
- Başvuru belge incelemesi olmadan onaylanamaz.
- Vatandaş bildirimi takip edilebilir.
- Yetkisiz personel kayıtları göremez.

LIVE / AUDIO:
- Yayın yetkisi ve sağlayıcı bağlantısı kontrol edilir.
- Bağlantı kesilmesi ve yeniden bağlanma test edilir.
- Moderatör kullanıcıyı susturabilir/çıkarabilir.
- Telif ve yayın politikası akışları belgelenir.

GAMING:
- Oyun durumu sunucuda doğrulanır.
- İstemci hileli hamle gönderemez.
- Bağlantı kopması sonrası yeniden katılım test edilir.
- Oyun sonucu ve skor tutarlı saklanır.

SECURITY:
- Yetkisiz erişim testleri
- IDOR testleri
- XSS/CSRF/SQL injection testleri
- Rate limit
- Dosya yükleme saldırıları
- Oturum yönetimi
- Hassas veri log kontrolü
- Yedekten geri yükleme testi

UI:
- Mobil dar ekran
- Tablet
- Masaüstü
- Türkçe karakter
- Uzun metin ve boş veri
- Erişilebilirlik
- Koyu/açık tema
- Loading/error/empty state

YAYIN ÖNCESİ:
- Kritik ve yüksek önem dereceli açık güvenlik hatası bulunmamalı.
- Kritik kullanıcı akışları uçtan uca test edilmeli.
- Yedekten geri dönüş denenmeli.
- İzleme ve alarm sistemi çalışmalı.
