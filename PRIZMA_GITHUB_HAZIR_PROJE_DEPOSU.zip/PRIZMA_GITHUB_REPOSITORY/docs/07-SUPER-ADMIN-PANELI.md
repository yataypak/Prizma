PRİZMA – SÜPER ADMİN PANELİ

GENEL:
Masaüstü öncelikli, responsive, rol bazlı yönetim paneli. Panelin tüm kritik işlemleri audit log ile izlenir.

SOL MENÜ:
1. Genel Bakış
2. Kullanıcılar
3. Kurumlar ve İşletmeler
4. Topluluklar
5. Modüller
6. Resmî Doğrulama
7. İçerik ve Moderasyon
8. Canlı Yayın ve Ses Odaları
9. Oyun ve Turnuvalar
10. Reklam ve Kampanyalar
11. Abonelik ve Ödemeler
12. Tasarım ve Temalar
13. Bildirimler
14. Raporlar ve Analitik
15. Sistem Sağlığı
16. Güvenlik ve Audit
17. Yedekleme
18. Ayarlar

DASHBOARD KARTLARI:
- Toplam kullanıcı
- Günlük/aylık aktif kullanıcı
- Yeni kayıtlar
- Aktif topluluklar
- Mesaj hacmi
- Aktif yayınlar
- Sipariş/ilan hacmi
- Açık raporlar
- API hata oranı
- Depolama ve kuyruk durumu

MODÜL FABRİKASI:
- Modül adı ve anahtarı
- İkon ve kategori rengi
- Açıklama ve izinler
- Veri alanları
- Form oluşturucu
- Kart/liste/detay şablonları
- Filtre ve sıralama
- Menü yerleşimi
- Bildirim kuralları
- Rol izinleri
- Önizleme
- Taslak/yayın
- Sürüm geçmişi ve geri alma

NOT:
Modül fabrikası, güvenli biçimde önceden tanımlanmış bileşenleri birleştirmelidir. Yönetim panelinden keyfî sunucu kodu çalıştırılmasına izin verilmemelidir.

RESMÎ DOĞRULAMA:
- Başvuru kuyruğu
- Kurum türü
- Resmî belge
- Yetkili kişi
- Alan adı/e-posta kontrolü
- İnceleme notu
- Onay/ret
- Yenileme ve yetki devri
- İtiraz
- İşlem geçmişi

MODERASYON:
- Rapor listesi
- Hedef içerik/hesap
- Risk seviyesi
- Kanıt ve bağlam
- İşlem önerisi
- İnsan incelemesi
- Yaptırım ve itiraz
- Tekrarlayan ihlal takibi

SİSTEM:
- Sağlık kontrolleri
- Kuyruk ve gecikme
- API yanıt süresi
- Hata izleme
- Depolama
- Yedekleme durumu
- Güvenlik olayları
- Sürüm ve dağıtım bilgisi
