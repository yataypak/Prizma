PRİZMA – ÜRÜN GEREKSİNİMLERİ

1. ÜRÜN İLKELERİ
- Tek hesap, çoklu deneyim.
- Topluluk kategorisi ve etkinleştirilen modüller ayrı kavramlardır.
- Kullanıcı kendi gizlilik ve bildirim tercihlerini belirler.
- Resmî rozet yalnızca doğrulanmış yetkili kurumlara verilir.
- Her modül gerçek iş akışına sahip olmalıdır.
- Modüller ortak kullanıcı, kimlik, bildirim ve yetki altyapısını paylaşır.

2. KULLANICI TİPLERİ
- Ziyaretçi
- Kayıtlı bireysel kullanıcı
- İşletme/kurumsal kullanıcı
- Topluluk sahibi
- Topluluk yöneticisi
- Moderatör
- Resmî kurum yetkilisi
- Platform personeli
- Süper Admin

3. ANA İŞ AKIŞLARI
A. Kayıt: yöntem seç → doğrulama → kullanıcı adı → profil → gizlilik tercihleri.
B. Mesaj: kişi bul → mesaj isteği/sohbet → medya/mesaj → bildirim → engelle/rapor.
C. Topluluk: keşfet → detay → katıl/başvuru → modüller → içerik/etkileşim.
D. İşletme: kurumsal profil → katalog → stok → sipariş → hazırlama → teslimat → değerlendirme.
E. İlan: ilan oluştur → moderasyon → yayınla → teklif/mesaj → satıldı.
F. Resmî kurum: belge başvurusu → yetkili doğrulama → resmî profil → duyuru/başvuru → işlem takibi.
G. Canlı yayın: yayın yetkisi → sağlayıcı bağlantısı → yayın başlat → izleyici etkileşimi → arşiv.
H. Oyun: oda oluştur → davet → sunucu doğrulamalı oyun → sonuç → raporlama.

4. İŞLEVSEL OLMAYAN GEREKSİNİMLER
- Performans: yaygın ekranlar düşük gecikmeyle açılmalı.
- Ölçek: kullanıcı ve topluluk sayısı arttıkça yatay ölçeklenebilirlik.
- Güvenlik: en az ayrıcalık, doğrulama, rate limit, audit log.
- Erişilebilirlik: klavye, ekran okuyucu, kontrast, metin boyutu.
- Uyumluluk: Android, iOS, modern web tarayıcıları ve masaüstü.
- Gözlemlenebilirlik: hata, gecikme, kuyruk, yayın ve API metrikleri.
- Yedekleme: düzenli, şifreli ve geri yükleme testli.
- Yerelleştirme: Türkçe başlangıç dili, diğer dillere hazır.
- Bakım: modüler kod, test, dokümantasyon ve sürümleme.

5. SINIRLAR VE DİKKAT
- AI Studio tek başına tüm canlı yayın, mesajlaşma, ödeme ve oyun altyapısını sağlamaz; backend ve harici sağlayıcılar gerekir.
- App Store/Google Play izinleri platform kurallarına tabidir.
- Ekran görüntüsü engelleme mutlak garanti değildir.
- Uçtan uca şifreleme doğru protokol ve güvenlik incelemesi gerektirir.
- Müzik/film/kitap içeriğinde lisans zorunlulukları değerlendirilmelidir.
- Resmî kurum doğrulaması belge ve yetki kontrolü gerektirir.
