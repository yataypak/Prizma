PRİZMA – EKRAN ENVANTERİ VE UI ŞARTNAMESİ

GENEL TASARIM:
- Mobil öncelikli.
- Ana zemin #0D0F12, kart #161920, marka vurgusu #D4AF37.
- Alt navigasyon dört ana sekme: Sohbetler, Kapsül, Meydan, Profil.
- Her ekranda tutarlı başlık, geri navigasyon, yüklenme, boş, hata ve yetki yok durumları.
- Dokunma hedefleri erişilebilir boyutta olmalı.
- Altın rengi yalnızca önemli eylem ve marka vurgularında kullanılmalı.

A. AÇILIŞ VE KAYIT
1. Splash: PRİZMA geometrik logo, kısa animasyon, slogan.
2. Hoş geldin: giriş, kayıt, dil seçimi, gizlilik bağlantıları.
3. Kayıt yöntemi: telefon/e-posta/kullanıcı adı.
4. Doğrulama: OTP veya e-posta doğrulaması.
5. Kullanıcı adı: benzersizlik kontrolü.
6. Profil kurulum: fotoğraf, ad, biyografi.
7. Gizlilik başlangıcı: telefon görünürlüğü, bulunabilirlik, mesaj istekleri.
8. İzinler: bildirim, kamera, mikrofon, konum; her izin gerekçesi açıklanmalı.

B. SOHBETLER
9. Sohbet listesi: arama, filtre, sabitlenenler, okunmamışlar.
10. Birebir sohbet: mesaj balonları, ek menüsü, yanıt, tepki, teslim/okundu durumu.
11. Grup sohbeti: başlık, üyeler, roller, medya ve dosyalar.
12. Yeni sohbet: kullanıcı arama, QR, önerilen kişiler.
13. Mesaj isteği: kabul et, reddet, engelle, raporla.
14. Sohbet bilgisi: medya, dosyalar, üyeler, bildirim, gizlilik.
15. Dosya kasası: klasörler, güvenli indirme, erişim kontrolü.
16. Zamanlanmış mesajlar: oluştur, düzenle, iptal et.
17. Arama ekranı: sesli/görüntülü, grup, bağlantı durumu.
18. Sohbet arama sonuçları: mesaj, dosya, bağlantı filtreleri.

C. KAPSÜL
19. Kapsül akışı: hikâye halkaları, içerik kartları.
20. Hikâye görüntüleme: yanıt, tepki, bağlantı/ürün/anket aksiyonu.
21. Hikâye oluşturma: fotoğraf/video/metin/ses.
22. Etkileşim ekleme: anket, ürün, ilan, konum, etkinlik, geri sayım.
23. Ortak hikâye: davet edilen katkıcılar ve onay.
24. Hikâye istatistikleri: görüntüleyenler ve etkileşimler.
25. Hikâye gizlilik: kişi/topluluk bazlı görünürlük.

D. MEYDAN
26. Meydan ana ekranı: arama, kategoriler, öneriler, trend topluluklar.
27. Kategori sayfası: filtre, sıralama, alt kategoriler.
28. Topluluk detay: kapak, açıklama, kurallar, üyeler, modül sekmeleri.
29. Topluluğa katılma: açık katılma, davet, başvuru.
30. Topluluk oluşturma sihirbazı: kimlik, kategori, gizlilik, modüller, tasarım.
31. Topluluk yönetim merkezi: üyeler, roller, içerik, modüller.
32. Modül seçici: etkinleştir/kapat, modül açıklaması ve gereksinimleri.
33. Topluluk içi arama: gönderi, üye, ürün, etkinlik.

E. PAZARYERİ VE İŞLETME
34. Pazaryeri keşfet: kategori, filtre, konum, fiyat.
35. İlan detay: galeri, fiyat, satıcı, teklif, sohbet.
36. İlan oluştur/düzenle: kategori, medya, fiyat, konum, durum.
37. Tekliflerim: teklif, karşı teklif, durum.
38. İşletme profili: logo, çalışma saati, adres, iletişim.
39. Ürün kataloğu: liste, stok, fiyat, varyant.
40. Ürün detay: gramaj/miktar, hazırlama tercihi, not.
41. Sepet: ürün, miktar, toplam, teslimat.
42. Sipariş oluşturma: adres, zaman, ödeme entegrasyonu, onay.
43. Sipariş takibi: alındı, hazırlanıyor, yola çıktı, teslim edildi.
44. İşletme sipariş paneli: kabul, ret, hazırlık, kurye.
45. Kampanya ve mahalle duyurusu.

F. RESMÎ KURUMLAR
46. Kurum profili: doğrulanmış rozet, hizmetler, duyurular.
47. Doğrulama başvurusu: belge, yetki, inceleme durumu.
48. Vatandaş bildirimi: kategori, açıklama, fotoğraf, konum.
49. Başvuru takip: durum, mesaj, sonuç.
50. Afet/acil duyuru: bölge, önem seviyesi, geçerlilik.
51. Kurum yönetim paneli: personel, duyuru, başvuru, rapor.

G. SPOR
52. Kulüp profili: branş, rozet, kadro, haber.
53. Fikstür: maç takvimi ve filtre.
54. Canlı skor: branşa özel skor bileşeni.
55. Lig tablosu: puan ve istatistik.
56. Takım/kadro: sporcu profilleri.
57. Taraftar tribünü: sohbet ve moderasyon.
58. Kulüp mağazası ve bilet bağlantıları.

H. YAYIN VE SOSYAL
59. Canlı yayın keşfet.
60. Canlı yayın izleme: video, sohbet, anket, PiP.
61. Yayın oluşturma/yönetimi: sağlayıcı, anahtar kasası, yayın durumu.
62. Radyo: canlı oynatıcı, program, istek.
63. Podcast arşivi.
64. Sesli oda listesi.
65. Sesli oda: konuşmacı/dinleyici, el kaldırma, moderasyon.
66. Görüntülü oda: katılımcı, kamera/mikrofon, moderasyon.

I. OYUN
67. Oyun salonu: oyun seçimi.
68. Oda listesi ve özel oda.
69. Oyun masası: oyuncu koltukları, sıra, süre, bağlantı.
70. Turnuva ve skor tablosu.
71. İzleyici görünümü ve raporlama.

J. FORUM, KÜLTÜR, EĞLENCE
72. Forum kategori ve konu listesi.
73. Konu detay ve yanıtlar.
74. Yeni konu oluşturma.
75. Blog akışı ve yazı detayı.
76. Kitaplık ve okuma listesi.
77. Kitap detay ve puanlama.
78. Sanatçı profili.
79. Film/dizi detay, fragman ve izleme listesi.
80. Etkinlik ve bilet bağlantıları.
81. Yemek tarifleri.
82. Tarif detayı ve alışveriş listesi.
83. Mekân keşfi ve QR menü.
84. Haber akışı.
85. Haber detay, kaynak ve düzeltme bilgisi.

K. PROFİL VE AYARLAR
86. Kişisel profil.
87. Kurumsal profil seçici.
88. Profil düzenleme.
89. Gizlilik merkezi.
90. Modül görünürlük ayarları.
91. Bildirim merkezi ve ses tercihleri.
92. Tema ve görünüm.
93. Dil ve erişilebilirlik.
94. Cihazlar ve oturumlar.
95. Güvenlik ve iki aşamalı doğrulama.
96. Yedekleme ve geri yükleme.
97. Veri dışa aktarma ve hesap silme.

L. SÜPER ADMİN WEB PANELİ
98. Genel dashboard.
99. Kullanıcı yönetimi.
100. Topluluk yönetimi.
101. Resmî doğrulama kuyruğu.
102. Rol ve izin yönetimi.
103. Modül fabrikası.
104. Tema/marka editörü.
105. Moderasyon ve raporlar.
106. Reklam ve gelir.
107. Sistem sağlığı, log ve denetim kayıtları.
108. Yedekleme ve kurtarma merkezi.

Her ekranın tasarımında gerçek veri durumları, yükleme, hata, boş içerik, çevrimdışı ve yetkisiz erişim halleri ayrıca hazırlanmalıdır.
