PRİZMA – GÖRSEL TASARIM SİSTEMİ

MARKA:
PRİZMA / Tek Mesaj, Sonsuz Dünya

RENKLER:
- Carbon: #0D0F12
- Surface: #161920
- Elevated surface: #202631
- Gold: #D4AF37
- Gold light: #F3D77A
- Text primary: #F5F6F7
- Text secondary: #A9B0BA
- Official blue: #2563EB
- Commerce green: #10A66A
- Sports/media orange: #F28C28
- Games/radio purple: #9254DE
- Forum teal: #16B8A6
- News red: #E5484D
- Culture burgundy: #9C4567

TİPOGRAFİ:
Modern sans-serif; başlıklar güçlü ve kısa; gövde metni yüksek okunabilirlikte. Türkçe karakterler eksiksiz desteklenmeli.

BİLEŞENLER:
- Primary, secondary, tertiary ve destructive butonlar
- Form alanları ve doğrulama durumları
- Avatar, rozet, etiket
- Mesaj balonları
- Hikâye halkaları
- Topluluk kartları
- Ürün ve ilan kartları
- Skor kartları
- Canlı yayın kartları
- Alt navigasyon
- Modal, bottom sheet, popover
- Toast ve bildirim
- Skeleton ve empty state

MOTION:
- Kısa, yumuşak geçişler
- Durum değişimlerinde mikro animasyon
- Animasyon azaltma tercihi
- İçerik okunabilirliğini bozan sürekli animasyonlardan kaçınma

RESPONSIVE:
- Mobil: alt navigasyon, tek kolon
- Tablet: iki kolon ve uyarlanabilir paneller
- Web: sol menü/yan panel ve içerik alanı
- Admin: masaüstü öncelikli veri tabloları ve filtreler

GÖRSEL ÜRETİM KURALI:
Konsept görsellerde cihaz çerçeveleri, gerçekçi arayüz kartları ve tutarlı marka renkleri kullanılabilir. Ancak görsel içindeki yazılar nihai UI metni sayılmamalı; gerçek uygulamada metinler erişilebilir ve düzenlenebilir bileşenlerle oluşturulmalıdır.
