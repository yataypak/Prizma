PRİZMA – GÜVENLİK VE GİZLİLİK ŞARTNAMESİ

1. KİMLİK
- Parolalar güçlü, güncel parola hash algoritmasıyla saklanmalı.
- MFA desteklenmeli.
- Oturum yenileme ve iptal güvenli olmalı.
- Şüpheli girişler ve yeni cihazlar bildirilmeli.
- Hesap kurtarma kötüye kullanıma karşı korunmalı.

2. YETKİLENDİRME
- Varsayılan ret (deny by default).
- Her istekte kullanıcı, topluluk, rol ve kaynak kontrolü.
- Kurum/işletme personeli yalnızca atanmış kaynaklara erişebilmeli.
- Admin işlemleri audit log üretmeli.
- Ayrıcalıklı işlemlerde yeniden doğrulama gerekebilir.

3. MESAJ GİZLİLİĞİ
- Uçtan uca şifreleme için standart, denetlenmiş protokol ve kütüphane kullan.
- Kendi kriptografik protokolünü tasarlama.
- Anahtar değişimi ve cihaz ekleme akışını güvenli tasarla.
- Şifreli yedeklemede kullanıcı kontrollü anahtar/kurtarma tasarımı sun.
- Sunucu tarafı arama ile E2EE arasında teknik sınırları açıkça belirt.

4. VERİ KORUMA
- Gereksiz kişisel veri toplama.
- Telefon/e-posta varsayılan olarak gizli.
- Konum yalnızca açık kullanıcı izniyle.
- Hassas verileri loglama.
- Veri saklama ve silme politikası.
- Kullanıcı veri dışa aktarma ve hesap silme akışı.
- KVKK ve uygulanabilir diğer mevzuata uygun aydınlatma/onay süreçleri.

5. DOSYA GÜVENLİĞİ
- MIME ve dosya içeriği doğrulaması.
- Zararlı dosya taraması.
- Boyut ve tür sınırları.
- Özel dosyalarda kısa süreli imzalı indirme bağlantıları.
- Yetkisiz herkese açık dosya URL'si üretme.

6. ABUSE / MODERASYON
- Kullanıcı raporu
- Engelleme
- Spam rate limit
- Sahte hesap ve dolandırıcılık sinyalleri
- Moderatör kuyruğu
- İtiraz süreci
- Şeffaf yaptırım kayıtları

7. PLATFORM SINIRLARI
- Ekran görüntüsü engelleme tüm cihazlarda garanti edilemez.
- Haricî kamera ile çekimi uygulama engelleyemez.
- IP gizleme için uygun relay/SFU mimarisi gerekir.
- Canlı yayın, müzik, film ve kitap içerikleri lisans gerektirebilir.
- Ödeme kartı verisi mümkünse sertifikalı ödeme sağlayıcısında tutulmalı; uygulama sunucusunda saklanmamalı.
