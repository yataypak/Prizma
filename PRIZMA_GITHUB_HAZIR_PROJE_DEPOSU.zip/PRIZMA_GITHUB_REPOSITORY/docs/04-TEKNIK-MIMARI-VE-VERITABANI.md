PRİZMA – TEKNİK MİMARİ VE VERİ MODELİ TASLAĞI

MİMARİ YAKLAŞIM:
Başlangıç için modüler monolit önerilir. Modül sınırları, servis arayüzleri ve veri sahipliği net tanımlanır. Trafik ve operasyon ihtiyacı oluştuğunda mesajlaşma, medya, bildirim, canlı yayın ve arama gibi alanlar bağımsız servislere ayrılabilir.

ANA BİLEŞENLER:
1. Client apps: Android, iOS, Web, Desktop.
2. API gateway/BFF: istemciye uygun API ve doğrulama.
3. Identity: kayıt, giriş, oturum, MFA, cihazlar.
4. User/Profile: kişisel ve kurumsal profiller.
5. Messaging: sohbet, mesaj, ek, teslim/okundu durumu.
6. Realtime: WebSocket olayları, çevrimiçi durumu.
7. Media: dosya, görsel, video, dönüştürme, depolama.
8. Capsule: hikâyeler ve etkileşimler.
9. Community: topluluk, üyelik, modül yapılandırması.
10. Marketplace: ilan, teklif, favori.
11. Commerce: katalog, sepet, sipariş, teslimat.
12. Official: doğrulama, kurum, vatandaş başvurusu.
13. Sports: branş, fikstür, skor, takım.
14. Broadcast: canlı yayın sağlayıcı adaptörü.
15. Audio: radyo, podcast, sesli oda.
16. Gaming: oda, oyun oturumu, sonuç.
17. Forum/Publishing: konu, yazı, kitap.
18. Entertainment/Food/News: ilgili içerik alanları.
19. Notification: push, e-posta, uygulama içi.
20. Security: yetki, audit, risk, şifreleme entegrasyonu.
21. Admin: sistem ve içerik yönetimi.
22. Billing: abonelik, ödeme sağlayıcı adaptörü.

VERİ TABANI TABLOLARI – TASLAK:
- users(id, username, email, phone, password_hash, status, created_at)
- user_verifications(id, user_id, method, verified_at, status)
- user_sessions(id, user_id, device_id, refresh_token_hash, expires_at)
- devices(id, user_id, platform, device_name, last_seen_at)
- profiles(id, user_id, profile_type, display_name, bio, avatar_id)
- organizations(id, owner_user_id, name, verification_status)
- organization_members(id, organization_id, user_id, role)
- communities(id, owner_user_id, name, slug, category_id, visibility, status)
- community_members(id, community_id, user_id, role, status, joined_at)
- community_modules(id, community_id, module_key, enabled, config_json)
- community_categories(id, name, parent_id)
- conversations(id, type, created_by, created_at)
- conversation_members(id, conversation_id, user_id, role)
- messages(id, conversation_id, sender_id, message_type, body_ciphertext, created_at, edited_at)
- message_attachments(id, message_id, media_id, metadata_json)
- message_receipts(id, message_id, user_id, delivered_at, read_at)
- media_objects(id, owner_id, storage_key, mime_type, size_bytes, checksum, status)
- stories(id, owner_id, community_id, media_id, story_type, expires_at)
- story_interactions(id, story_id, user_id, interaction_type, payload_json)
- listings(id, seller_id, community_id, title, description, price, currency, condition, status)
- listing_media(id, listing_id, media_id)
- offers(id, listing_id, buyer_id, amount, status)
- products(id, organization_id, title, sku, price, stock, unit)
- carts(id, user_id, organization_id, status)
- cart_items(id, cart_id, product_id, quantity, options_json)
- orders(id, buyer_id, organization_id, status, total_amount, delivery_address_id)
- order_items(id, order_id, product_id, quantity, unit_price, options_json)
- official_verifications(id, organization_id, submitted_by, documents_json, status, reviewed_by)
- citizen_reports(id, organization_id, user_id, category, description, location, status)
- sports_clubs(id, organization_id, sport_type, verification_status)
- teams(id, sports_club_id, name, season)
- fixtures(id, team_id, opponent, starts_at, status, score_json)
- forum_topics(id, community_id, author_id, title, body, status)
- forum_replies(id, topic_id, author_id, body, created_at)
- events(id, community_id, title, starts_at, location, ticket_url)
- notifications(id, user_id, type, payload_json, read_at)
- reports(id, reporter_id, target_type, target_id, reason, status)
- audit_logs(id, actor_id, action, target_type, target_id, metadata_json, created_at)
- subscriptions(id, user_id, plan_id, status, period_end)
- payments(id, user_id, provider, provider_reference, amount, currency, status)

VERİ MODELİ KURALLARI:
- Tüm tablolarda uygun primary key ve indeksler.
- Kullanıcıya ait verilerde erişim kontrolü.
- Silme işlemlerinde yasal saklama ve audit politikası.
- Para değerlerinde decimal ve ISO para birimi kodu.
- Saatler UTC saklanmalı, istemcide yerel saate çevrilmeli.
- Büyük medya dosyaları veritabanına blob olarak konmamalı; nesne depolama kullanılmalı.
- JSON alanları yalnızca esnek modül konfigürasyonu gibi uygun yerlerde kullanılmalı.
- Hassas alanlar gereksiz yere loglanmamalı.
