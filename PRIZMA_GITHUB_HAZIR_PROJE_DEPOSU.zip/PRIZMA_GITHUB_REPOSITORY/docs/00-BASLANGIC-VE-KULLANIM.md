PRİZMA – YAPAY ZEKÂ DESTEKLİ GELİŞTİRME PAKETİ
Sürüm: 1.0
Dil: Türkçe
Hedef: Google AI Studio, Gemini tabanlı geliştirme ortamları ve benzeri kod üretim araçları

BU PAKET NE İÇERİR?
- PRİZMA ürün vizyonu ve kapsamı
- Kullanıcı akışları ve ekran şartnamesi
- Görsel tasarım sistemi
- Teknik mimari önerisi
- Veri modeli ve API taslağı
- Güvenlik ve gizlilik gereksinimleri
- Süper Admin paneli şartnamesi
- Test ve kabul kriterleri
- Yapay zekâya verilecek ana geliştirme talimatı
- Görsel konsept referansı

ÖNEMLİ:
Görseller gerçek çalışan uygulamadan alınmış ekran görüntüleri değildir. Tasarım yönünü ve ekranların nasıl görünmesi gerektiğini anlatan konsept referanslarıdır.
Bu dokümanlar ürün gereksinimlerini tanımlar; gerçek uygulama kodunun, entegrasyonların, testlerin ve mağaza yayın süreçlerinin ayrıca geliştirilmesi gerekir.

NASIL KULLANILIR?
1. Önce 01_ANA_GELISTIRME_PROMPTU.txt dosyasını AI Studio'ya verin.
2. Ardından bu ZIP içindeki diğer dokümanları proje bağlamı olarak yükleyin.
3. Modelden tüm projeyi tek seferde yüzeysel üretmesini değil, modülleri sırayla gerçek çalışan kodla geliştirmesini isteyin.
4. Her aşamada çalışan kod, dosya listesi, kurulum talimatı ve test raporu talep edin.
5. Bir aşama testleri geçmeden sonraki aşamaya geçmeyin.

ÖNERİLEN İLK İSTEK:
"Bu ZIP içindeki tüm dokümanları oku. Önce gereksinimleri analiz et, çelişkileri ve eksik kararları listele. Ardından mimariyi, klasör yapısını, veri modelini ve geliştirme aşamalarını oluştur. Henüz kod yazmaya başlama; önce uygulanabilir teknik planı ve riskleri sun."

PRİZMA
Slogan: Tek Mesaj, Sonsuz Dünya
