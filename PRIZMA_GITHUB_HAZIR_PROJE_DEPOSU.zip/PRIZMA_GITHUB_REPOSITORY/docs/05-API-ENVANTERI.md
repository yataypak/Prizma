PRİZMA – API ENVANTERİ TASLAĞI

API standardı: versioned REST/JSON; gerçek zamanlı olaylar için WebSocket veya uygun event transport. Büyük medya için doğrudan object storage upload URL akışı.

AUTH
POST /v1/auth/register
POST /v1/auth/login
POST /v1/auth/verify
POST /v1/auth/refresh
POST /v1/auth/logout
POST /v1/auth/mfa/enable
POST /v1/auth/mfa/verify
GET  /v1/auth/sessions
DELETE /v1/auth/sessions/{id}

USERS / PROFILES
GET /v1/users/{id}
GET /v1/users/search?q=
PATCH /v1/profiles/me
POST /v1/profiles/business
GET /v1/profiles/business
POST /v1/profiles/business/{id}/members

MESSAGING
GET /v1/conversations
POST /v1/conversations
GET /v1/conversations/{id}
GET /v1/conversations/{id}/messages
POST /v1/conversations/{id}/messages
PATCH /v1/messages/{id}
DELETE /v1/messages/{id}
POST /v1/messages/{id}/reactions
POST /v1/messages/{id}/read
POST /v1/messages/scheduled

CAPSULE
GET /v1/stories/feed
POST /v1/stories
GET /v1/stories/{id}
POST /v1/stories/{id}/interactions
DELETE /v1/stories/{id}

COMMUNITIES
GET /v1/communities
POST /v1/communities
GET /v1/communities/{id}
POST /v1/communities/{id}/join
POST /v1/communities/{id}/leave
GET /v1/communities/{id}/members
PATCH /v1/communities/{id}/modules
POST /v1/communities/{id}/invites

MARKETPLACE
GET /v1/listings
POST /v1/listings
GET /v1/listings/{id}
PATCH /v1/listings/{id}
POST /v1/listings/{id}/offers
POST /v1/listings/{id}/favorite

COMMERCE
GET /v1/organizations/{id}/products
POST /v1/organizations/{id}/products
POST /v1/carts
POST /v1/orders
GET /v1/orders/{id}
PATCH /v1/orders/{id}/status

OFFICIAL
POST /v1/official-verifications
GET /v1/official-verifications/{id}
POST /v1/citizen-reports
GET /v1/citizen-reports/{id}

SPORTS
GET /v1/clubs/{id}
GET /v1/teams/{id}/fixtures
GET /v1/fixtures/{id}/score

FORUM
GET /v1/communities/{id}/topics
POST /v1/communities/{id}/topics
POST /v1/topics/{id}/replies
POST /v1/topics/{id}/votes

NOTIFICATIONS
GET /v1/notifications
POST /v1/notifications/{id}/read
PATCH /v1/notification-preferences

ADMIN
GET /v1/admin/dashboard
GET /v1/admin/users
GET /v1/admin/communities
GET /v1/admin/reports
POST /v1/admin/verifications/{id}/decision
POST /v1/admin/modules
PATCH /v1/admin/themes
GET /v1/admin/audit-logs

API GÜVENLİĞİ:
- Her endpoint kimlik doğrulama ve kaynak bazlı yetkilendirme yapmalı.
- Rate limit ve abuse koruması olmalı.
- Pagination, filtre ve sıralama standart olmalı.
- Idempotency key ödeme/sipariş gibi kritik işlemlerde kullanılmalı.
- Hata cevapları tutarlı kod ve mesaj formatı taşımalı.
- API sürümlenmeli ve OpenAPI dokümantasyonu üretilmeli.
