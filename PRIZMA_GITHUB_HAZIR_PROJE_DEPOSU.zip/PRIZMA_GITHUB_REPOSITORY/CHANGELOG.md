# Değişiklik Günlüğü

Bu dosya proje gereksinimleri, mimari kararları ve uygulama sürümlerindeki anlamlı değişiklikleri kaydeder.

## [0.1.0] — 2026-11-18
- PRİZMA ürün kapsamı ve gereksinim dokümanları GitHub deposu yapısına taşındı.
- Ekran envanteri, tasarım sistemi, teknik mimari, API, güvenlik ve Süper Admin şartnameleri eklendi.
- Yapay zekâ ajanları için `AGENTS.md` çalışma kuralları eklendi.
- Katkı rehberi, issue ve pull request şablonları eklendi.
- Görsel konsept ve mobil ekran haritası referansları eklendi.
