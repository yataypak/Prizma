# PRİZMA — Tek Mesaj, Sonsuz Dünya

PRİZMA; bireysel mesajlaşma, hikâyeler, dinamik topluluklar, pazaryeri, yerel işletme siparişleri, spor, canlı yayın, radyo, sosyal odalar, oyunlar, forum, kültür, eğlence, yemek ve haber deneyimlerini ortak bir platformda birleştirmeyi hedefleyen çok modüllü bir iletişim ürünüdür.

> **Bu depo şu an ürün gereksinimleri, tasarım referansları ve geliştirme talimatlarını içerir.** Tamamlanmış/çalışan uygulama kaynak kodu değildir.

## Başlangıç

Projeye katkı vermeden önce şu dosyaları sırayla okuyun:

1. [`AGENTS.md`](AGENTS.md) — tüm yapay zekâ ajanları ve geliştiriciler için zorunlu çalışma kuralları.
2. [`prompts/ANA-GELISTIRME-PROMPTU.md`](prompts/ANA-GELISTIRME-PROMPTU.md) — ana ürün ve geliştirme talimatı.
3. [`docs/01-URUN-GEREKSINIMLERI.md`](docs/01-URUN-GEREKSINIMLERI.md) — ürün kapsamı.
4. [`docs/02-EKRAN-ENVANTERI-VE-UI.md`](docs/02-EKRAN-ENVANTERI-VE-UI.md) — ekran envanteri.
5. [`docs/04-TEKNIK-MIMARI-VE-VERITABANI.md`](docs/04-TEKNIK-MIMARI-VE-VERITABANI.md) — mimari ve veri modeli.
6. [`project/ROADMAP.md`](project/ROADMAP.md) — geliştirme aşamaları.

## Depo yapısı

```text
.
├── README.md
├── AGENTS.md
├── CHANGELOG.md
├── CONTRIBUTING.md
├── LICENSE
├── .gitignore
├── .github/
│   ├── ISSUE_TEMPLATE/
│   └── PULL_REQUEST_TEMPLATE/
├── assets/
│   └── design-references/
├── docs/
├── prompts/
└── project/
```

## Proje ilkeleri

- Android, iOS, Web ve masaüstü hedefleri birlikte değerlendirilir.
- Mobil öncelikli, responsive ve erişilebilir arayüz tasarlanır.
- Dört ana gezinme alanı: **Sohbetler, Kapsül, Meydan, Profil**.
- Topluluk kategorisi ile topluluk modülleri birbirinden ayrıdır.
- Resmî kurum rozeti yalnızca yetkisi doğrulanmış kurumlara verilir.
- Güvenlik ve yetkilendirme sunucu tarafında uygulanır.
- Çalışmayan butonlar veya üretim özelliği gibi sunulan sahte akışlar kabul edilmez.
- Telif, ödeme, canlı yayın, şifreleme ve mevzuat gereksinimleri ayrıca doğrulanır.

## Yapay zekâ ile çalışma

Bu depoyu bir yapay zekâ aracına verdiğinizde önce `AGENTS.md` dosyasını okutun. Ajanın önce depoyu analiz etmesini, mevcut durumu raporlamasını ve küçük görevler üzerinden ilerlemesini isteyin. Büyük ve belirsiz değişiklikleri tek seferde yaptırmayın.

Örnek başlangıç isteği:

> Bu GitHub deposunu tamamen incele. Önce AGENTS.md ve README.md dosyalarına uy. Mevcut dosyaları değiştirmeden önce mimari boşlukları, çelişkileri, riskleri ve uygulanabilir ilk geliştirme adımını raporla. Henüz kod üretme. Sonraki adımda küçük, test edilebilir bir görev için plan ve etkilenecek dosyaları öner.

## Durum

Proje gereksinim ve tasarım hazırlığı aşamasındadır. Gerçek uygulama kaynak kodu, çalışan backend, canlı yayın/ödeme sağlayıcıları ve mağaza dağıtımı henüz bu doküman paketinin parçası değildir.

## Katkı

Değişiklikler için `CONTRIBUTING.md` ve pull request şablonunu izleyin. Her özellik için gereksinim, ekran, API, veri modeli, yetki, hata durumları ve test etkisini açıklayın.
